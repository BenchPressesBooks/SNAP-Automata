local http = require 'socket.http'

local function extract(basename)
	local text = assert(http.request("http://mayhewlabs.com/webGerber/?demo="..basename))
	
	for id,content in text:gmatch('<script type=text/x%-gerber id=(.-)>(.-)</script>') do
		local extension = id:match('%.([^.]*)$'):lower()
		local file = assert(io.open(basename.."."..extension, "wb"))
		assert(file:write(content))
		assert(file:close())
	end
end

extract('Go_Between_Shield')
extract('LilyPad')
extract('Fio')
extract('Electric_Sheep')
