thickness = 0.2
mask_silkscreen = false
materials = {
	substrate = '#bf561e',
	copper = '#442423', -- not really http://en.wikipedia.org/wiki/copper_(color)
	soldermask = { color='#bf561e', opacity=0.5, mask=true },
	finish = '#f2c868', -- not really http://en.wikipedia.org/wiki/Gold_(color)
	silkscreen = '#ffffff',
--	paste = '#e6e8fa',
}

