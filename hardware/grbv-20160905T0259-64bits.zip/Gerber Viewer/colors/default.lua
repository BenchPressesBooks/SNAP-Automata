thickness = 1.6
mask_silkscreen = false
materials = {
	substrate = '#0e2c0e',
	copper = '#b87333', -- http://en.wikipedia.org/wiki/Copper_(color)
	soldermask = { color='#5e9806', opacity=0.5, mask=true },
	silkscreen = '#ffffff',
	paste = '#e6e8fa',
}

