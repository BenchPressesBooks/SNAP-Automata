// Define Other Network Settings
#define NET_GATEWAY (<REDACTED>)
#define NET_SUBNET (<REDACTED>)
#define NET_DNS (<REDACTED>)