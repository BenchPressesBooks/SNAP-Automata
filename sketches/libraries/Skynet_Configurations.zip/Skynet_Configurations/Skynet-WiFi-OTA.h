// OTA Server Configuration
#define OTA_SERV_IP "<REDACTED>"
#define OTA_SERV_PORT <REDACTED>