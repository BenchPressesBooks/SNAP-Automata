// Define Wireless Network Configuration
#define WIFI_SSID "<REDACTED>"
#define WIFI_PASSWORD "<REDACTED>"