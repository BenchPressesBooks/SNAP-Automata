// MQTT Server Configuration
#define MQTT_SERV_IP "<REDACTED>"
#define MQTT_SERV_PORT <REDACTED>
#define MQTT_USER_INT "<REDACTED>"
#define MQTT_USER_EXT "<REDACTED>"
#define MQTT_PASS_INT "<REDACTED>"
#define MQTT_PASS_EXT "<REDACTED>"