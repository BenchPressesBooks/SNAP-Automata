Skynet Configuration Library
------------------------------------------------------
This collection of header files contains network, server, and device configuration details that should be constant between all devices of the same device class.    IE: Hardwired vs Wireless devices.

OTA and WiFi header files are only needed if the device is wireless.

If the device is wired only include network and mqtt header files.